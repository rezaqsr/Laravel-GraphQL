<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GraphQL Using Laravel</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/GraphQL.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-[#402B3A]">


<div id="searchModal" class="modal">
    <div class="content">
        <form id="form" action="">
            <input class="search-input" type="text" placeholder="Search ...."/>
            <div class="flex gap-5 text-[#949494] items-center mt-4">
                <div class="radio">
                    <input id="radio-1" name="radio" type="radio" value="genre" checked>
                    <label for="radio-1" class="radio-label">Genre</label>
                </div>
                <div class="radio">
                    <input id="radio-2" name="radio" type="radio" value="director">
                    <label  for="radio-2" class="radio-label">Director</label>
                </div>

            </div>

        </form>


        <div class="results">
            <ul id="AjaxResults">

            </ul>
        </div>
    </div>
    <button data-dismiss="modal"><i class="material-icons">close</i><span>ESC</span></button>
</div>
<div id="searchModal2" class="modal">
    <div class="content">
        <div class="tab-container">
            <input type="radio" name="tabs" id="tab1" class="tab-radio" checked>
            <label for="tab1" class="tab-label">Movies</label>
            <div class="tab-content">
                <form id="form_movies" action="">
                    <div class="grid lg:grid-cols-2 grid-cols-1 gap-2">
                        <input name="name" id="name" type="text" placeholder="Name Of the Movie">
                        <select name="director" id="directors"></select>
                        <input type="text" name="overview" id="overview" placeholder="Overview Of the Movie">
                        <input type="text" name="budget" id="budget" placeholder="Budget Of the Movie">
                        <input type="text" name="boxOffice" id="boxOffice" placeholder="Box Office Of the Movie">
                        <input type="text" name="year" id="year" placeholder="Year Of the Movie">
                        <input type="text" name="country" id="country" placeholder="Country Of the Movie">
                        <div id="genres" class="grid lg:grid-cols-4 grid-cols-1 text-[#FF9BD2] justify-items-start">

                        </div>
                    </div>
                    <button type="submit" class="rounded bg-[#402B3A] text-[#FF9BD2] p-4 mt-8 w-full hover:text-[#402B3A] hover:bg-[#FF9BD2] transition">Submit</button>
                </form>
            </div>

            <!-- Tab 2 -->
            <input type="radio" name="tabs" id="tab2" class="tab-radio">
            <label for="tab2" class="tab-label">Director / Genre</label>
            <div class="tab-content">
                <form id="form_gd" action="">
                    <div class="grid grid-cols-1 gap-2">
                        <input name="name" id="name" type="text" placeholder="Name Of the Movie">
                        <div class="flex gap-5 text-[#949494] items-center mt-4">
                            <div class="radio">
                                <input id="radio-1" name="form_gd" type="radio" value="genre" checked>
                                <label for="radio-1" class="radio-label">Genre</label>
                            </div>
                            <div class="radio">
                                <input id="radio-2" name="form_gd" type="radio" value="director">
                                <label  for="radio-2" class="radio-label">Director</label>
                            </div>

                        </div>
                    </div>
                    <button type="submit" class="rounded bg-[#402B3A] text-[#FF9BD2] p-4 mt-8 w-full hover:text-[#402B3A] hover:bg-[#FF9BD2] transition">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <button data-dismiss="modal"><i class="material-icons">close</i><span>ESC</span></button>
</div>
<div class="container mx-auto mt-8">
    <div  data-toggle="modal" data-target="searchModal2" class="w-fit p-2 bg-[#FF9BD2] text-[ rounded cursor-pointer">
       Add New
    </div>
    <div class="flex justify-center items-center gap-4">
        <h1 id="title" class="my-12 text-[#FF9BD2] font-bold text-3xl text-center">List Of Movies</h1>
        <div  data-toggle="modal" data-target="searchModal" class="w-6 h-6 rotate-90 cursor-pointer">
            <svg fill="#FF9BD2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path
                    d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/>
            </svg>
        </div>

    </div>
    <div id="moviesList" class="grid lg:grid-cols-2 grid-cols-1 gap-5 mb-4"></div>
</div>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Downloads\Documents\GraphQL\Laravel-GraphQL\resources\views/graphql.blade.php ENDPATH**/ ?>